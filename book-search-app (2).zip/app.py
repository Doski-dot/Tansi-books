from flask import Flask, request, render_template_string, jsonify
import json
import os

app = Flask(__name__)

BOOKS_JSON_PATH = os.path.join(os.path.dirname(__file__), "books_data.json")
with open(BOOKS_JSON_PATH, "r") as f:
    books = json.load(f)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Library Book Search</title>
    <script>
    async function suggestTitles() {
        const input = document.getElementById('search-box').value;
        if (input.length < 2) return;
        const res = await fetch(`/suggest?q=${input}`);
        const suggestions = await res.json();
        const datalist = document.getElementById("title-suggestions");
        datalist.innerHTML = "";
        suggestions.forEach(s => {
            const option = document.createElement("option");
            option.value = s;
            datalist.appendChild(option);
        });
    }
    </script>
</head>
<body>
    <h1>Library Book Search</h1>
    <form method="GET" action="/search">
        <input type="text" id="search-box" name="q" placeholder="Search by title, author, or subject" oninput="suggestTitles()" list="title-suggestions" required>
        <datalist id="title-suggestions"></datalist>
        <button type="submit">Search</button>
    </form>
    {% if results %}
        <h2>Results for '{{ query }}':</h2>
        <ul>
            {% for book in results %}
                <li>
                    <strong>{{ book.title }}</strong><br>
                    Author: {{ book.author }}<br>
                    Subject: {{ book.subject }}<br>
                    Year: {{ book.year }}<br>
                    ISBN: {{ book.isbn }}<br>
                </li>
            {% endfor %}
        </ul>
    {% elif query %}
        <p>No books found matching your search.</p>
    {% endif %}
</body>
</html>
"""

@app.route("/")
def index():
    return render_template_string(HTML_TEMPLATE, results=None, query=None)

@app.route("/search")
def search():
    query = request.args.get("q", "").strip().lower()
    results = []
    if query:
        for book in books:
            if (query in book["title"].lower() or
                query in book["author"].lower() or
                query in book["subject"].lower()):
                results.append(book)
    return render_template_string(HTML_TEMPLATE, results=results, query=query)

@app.route("/suggest")
def suggest():
    query = request.args.get("q", "").lower()
    suggestions = [book["title"] for book in books if query in book["title"].lower()]
    return jsonify(suggestions[:10])

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
